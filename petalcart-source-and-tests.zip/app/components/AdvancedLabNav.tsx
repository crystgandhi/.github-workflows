export default function AdvancedLabNav() {
  return (
    <nav className="direct-lab-nav" aria-label="Advanced automation labs">
      <span>Jump to a lab</span>
      <a href="#visual-regression">◫ Visual Regression</a>
      <a href="#chatbot-testing">✿ Chatbot Testing</a>
      <a href="#api-simulation">↗ API Simulation</a>
      <a href="#accessibility-testing">◎ Accessibility</a>
    </nav>
  );
}
