type ScenarioGridProps = {
  onOpenWishlistCart: () => void;
  onOpenCheckout: () => void;
};

const scenarios = [
  ["Wishlist & cart", "Persist items, update quantities, and validate totals."],
  ["Checkout wizard", "Test address validation, coupons, and step navigation."],
  ["Visual regression", "Interactive comparison lab is ready to test."],
  ["API simulation", "Practice loading, empty, error, and delayed-response states."],
  ["Accessibility", "Verify keyboard flow, focus order, names, and contrast."],
  ["Chatbot testing", "Interactive intent and response test suite is ready."],
] as const;

const labLinks: Record<string, string> = {
  "Visual regression": "#visual-regression",
  "API simulation": "#api-simulation",
  Accessibility: "#accessibility-testing",
  "Chatbot testing": "#chatbot-testing",
};

export default function ScenarioGrid({ onOpenWishlistCart, onOpenCheckout }: ScenarioGridProps) {
  return (
    <section className="scenarios" id="scenarios">
      <p className="eyebrow">Automation scenarios</p>
      <h2>Practice every feature</h2>
      <div className="scenario-grid">
        {scenarios.map(([name, description], index) => (
          <article key={name} className="scenario-complete">
            <span>0{index + 1}</span>
            <h3>{name}</h3>
            <p>{description}</p>
            {name === "Wishlist & cart" && <button onClick={onOpenWishlistCart} data-testid="open-wishlist-cart-lab">Open lab →</button>}
            {name === "Checkout wizard" && <button onClick={onOpenCheckout} data-testid="open-checkout-wizard">Open wizard →</button>}
            {labLinks[name] && <a href={labLinks[name]}>Open lab →</a>}
          </article>
        ))}
      </div>
    </section>
  );
}
