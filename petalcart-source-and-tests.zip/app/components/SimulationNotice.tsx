type SimulationNoticeProps = {
  children: React.ReactNode;
};

export default function SimulationNotice({ children }: SimulationNoticeProps) {
  return (
    <aside className="simulation-notice" role="note">
      <span aria-hidden="true">ⓘ</span>
      <p><strong>Practice simulation:</strong> {children}</p>
    </aside>
  );
}
